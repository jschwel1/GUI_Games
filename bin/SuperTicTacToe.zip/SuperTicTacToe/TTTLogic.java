package SuperTicTacToe;

public class TTTLogic {
	public TTTLogic(){
		
	}
}
