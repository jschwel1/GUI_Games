package SuperTicTacToe;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class TTTPane extends JPanel implements MouseListener{
	int HEIGHT = 750;
	int WIDTH = 750;
	Board[][] bigBoard;
	Board overView;
	ArrayList<Point> playableBoard; 
	boolean freeChoice;
	int freePlaces;
	int winPlaces;
	Point lastBoard;
	char player;
	Font lPiece;
	Font bPiece;
	Font smallText;

	public static final char EMPTY = ' ';
	public static final char PLAYER1 = 'X';
	public static final char PLAYER2 = 'O';
	public TTTPane(){
		//		JOptionPane.showMessageDialog(this, "Welcome to java Super-Tic-Tac-Toe! this program was written by me, Jacob Schwell so that you can waste a little more time from your day and hopefully \nenjoy a pretty neat game. \nP.S. I have no clue who made this game or where it came from, but credit to Brian for showing it to me. have fun!");
		// board stuff
		bigBoard = new Board[3][3];
		playableBoard = new ArrayList<Point>();
		for (int i = 0; i < 3; i++){
			for (int j = 0; j < 3; j++){
				bigBoard[i][j] = new Board();
				playableBoard.add(new Point(i,j));
			}
		}
		lastBoard = new Point(1,1);
		player = 'X';
		overView = new Board();
		freeChoice = false;
		freePlaces = 81; // freePlaces >= winPlaces (always)
		winPlaces = 0;
		
		this.addMouseListener(this);
		
		// fonts
		lPiece = new Font(Font.MONOSPACED, Font.PLAIN, (WIDTH-42)/9);
		bPiece = new Font(Font.MONOSPACED, Font.PLAIN, (WIDTH-5)/3);
		smallText = new Font(Font.SERIF, Font.PLAIN, 10);
	}

	public void reset(){
		bigBoard = new Board[3][3];
		playableBoard.clear();
		for (int i = 0; i < 3; i++){
			for (int j = 0; j < 3; j++){
				bigBoard[i][j] = new Board();
				playableBoard.add(new Point(i,j));
			}
		}
		lastBoard = new Point(1,1);
		player = 'X';
		overView = new Board();
	}

	public void paintComponent(Graphics g){
		// Background
		g.setColor(Color.black);
		g.fillRect(0, 0, WIDTH, HEIGHT);

		// playable board background
		g.setColor(new Color(0,41,1));
		for(Point p: playableBoard)
			g.fillRect(p.x*(WIDTH)/3, p.y*(HEIGHT)/3, (WIDTH/3)-1, (HEIGHT/3)-1);

		// big lines
		g.setColor(Color.yellow);
		g.fillRect((WIDTH-8)/3, 0, 4, HEIGHT);
		g.fillRect((WIDTH-8)*2/3, 0, 4, HEIGHT);
		g.fillRect(0, (HEIGHT-8)/3, WIDTH, 4);
		g.fillRect(0, (HEIGHT-8)*2/3, WIDTH, 4);
		// little lines
		for (int i = 0; i < 3; i++){
			for (int j = 0; j < 3; j++){
				g.fillRect((WIDTH-6)/3*i+(WIDTH-6)/9, (HEIGHT)/3*j+15, 3, (HEIGHT)/3-30);
				g.fillRect((WIDTH-6)/3*i+(WIDTH-6)*2/9, (HEIGHT)/3*j+15, 3, (HEIGHT)/3-30);
				g.fillRect((HEIGHT)/3*j+15,(WIDTH-6)/3*i+(WIDTH-6)/9, (HEIGHT)/3-30, 3);
				g.fillRect((HEIGHT)/3*j+15,(WIDTH-6)/3*i+(WIDTH-6)*2/9, (HEIGHT)/3-30, 3);
			}
		}
		// Pieces

		g.setFont(lPiece);
		g.setColor(Color.red);



		for (int bR = 0; bR < 3; bR++){
			for (int bC = 0; bC < 3; bC++){
				for (int lR = 0; lR < 3; lR++){
					for (int lC = 0; lC < 3; lC++){
						g.drawString(bigBoard[bR][bC].getCharAt(lR, lC)+"", (int)(WIDTH*(1.0/27.0)) + ((WIDTH-5)*lC/9) + ((WIDTH-5)*bC/3), (int)(HEIGHT*(1.0/10.0)) + (HEIGHT-5)*lR/9 + (HEIGHT-5)*bR/3);	
					}
				}
			}
		}

		g.setColor(Color.blue);
		g.setFont(bPiece);
		for (int r = 0; r < 3; r++){
			for (int c = 0; c < 3; c++){
				g.drawString(overView.getCharAt(r,c)+"", WIDTH/16 + (WIDTH*c/3), (int)(HEIGHT*(17.0/64.0))+HEIGHT*r/3);
			}
		}

		g.setFont(smallText);
		g.setColor(Color.white);
		g.drawString("Written by: Jacob Schwell", 600, 745);
	}



	public void mousePressed(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();

		int bRow = y*3/(HEIGHT-8);
		int bCol = x*3/(WIDTH-8);

		int lRow = ((y-5)*9/HEIGHT)%3;
		int lCol = ((x-5)*9/WIDTH)%3;

		// place piece
		if (playableBoard.contains(new Point(bCol,bRow))){
			boolean okay = true;
			if (freeChoice){
				okay = false;
				winPlaces = 0;
				freePlaces = 0;
				// get freePlaces and winPlaces
				for (int bR = 0; bR < 3; bR++){
					for (int bC = 0; bC < 3; bC++){
						for (int lR = 0; lR < 3; lR++){
							for (int lC = 0; lC < 3; lC++){
								if (bigBoard[bR][bC].getCharAt(lR, lC) == EMPTY)
									freePlaces++;
								if (bigBoard[bR][bC].givesWin(lR, lC, player))
									winPlaces++;
							}
						}
					}
				}
				System.out.println("free places: " + freePlaces + "   winPlaces: " + winPlaces);
				// if freeplaces is == winPlaces, okay
				if (freePlaces == winPlaces)
					okay = true;
				// if freePlaces > winPlaces, check that the spot doesn't give a win
				else{
					if (!bigBoard[bRow][bCol].givesWin(lRow, lCol, player))
						okay = true;
				}
			}
			if (okay) {
				// if piece was place, change turns
				if (bigBoard[bRow][bCol].placePiece(lRow, lCol, player) == 0){
					// check for little board winner or full
					if (bigBoard[bRow][bCol].hasWin()){
						// check for big board winner
						overView.placePiece(bRow, bCol, player);
						if (overView.hasWin()){
							if (JOptionPane.showConfirmDialog(this, "Congratulations player" + overView.getWinner() + ", you won! would you like to start another game?", "WE HAVE A WINNER!!!", JOptionPane.YES_NO_OPTION) == 0);
							reset();
						}
					}
					// change players:
					if (player == PLAYER1)
						player = PLAYER2;
					else
						player = PLAYER1;

					// get playable board(s)
					playableBoard.clear();
					// if you can't play on the next board, check if you can play on the same one
					if (bigBoard[lRow][lCol].isFull() || bigBoard[lRow][lCol].hasWin()){
						System.out.println("a");
						// otherwise add the same board
						if (!bigBoard[bRow][bCol].isFull() && !bigBoard[bRow][bCol].hasWin()){
							freeChoice = false;
							playableBoard.add(new Point(bCol, bRow));
							System.out.println("c");
						}
						// is the same board unplayable?
						else {
							System.out.println("b");
							// add all possible boards
							freeChoice = true;
							for(int i = 0; i < 3; i++){
								for (int j = 0; j < 3; j++){
									System.out.println(i+","+j+" is full? " +  bigBoard[i][j].isFull() + "   has win? " + bigBoard[i][j].hasWin());
									if ((!bigBoard[i][j].isFull()) && (!bigBoard[i][j].hasWin())){
										playableBoard.add(new Point(j,i));
									}
								}
							}
						}

					}
					else{
						playableBoard.add(new Point(lCol, lRow));
						freeChoice = false;
						System.out.println("d");
					}
					System.out.println(playableBoard);
				}
			}
		}
		lastBoard = new Point(bCol, bRow);
		repaint();
	}

	public void mouseClicked(MouseEvent arg0) {}
	public void mouseEntered(MouseEvent arg0) {}
	public void mouseExited(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
}
